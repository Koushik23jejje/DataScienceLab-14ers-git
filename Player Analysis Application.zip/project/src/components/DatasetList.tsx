import React from 'react';

interface Dataset {
  id: number;
  name: string;
  description: string;
  size: string;
}

const datasets: Dataset[] = [
  {
    id: 1,
    name: "Iris Dataset",
    description: "Classic dataset for classification",
    size: "150 samples"
  },
  {
    id: 2,
    name: "Boston Housing",
    description: "Regression analysis dataset",
    size: "506 samples"
  },
  {
    id: 3,
    name: "MNIST",
    description: "Handwritten digits dataset",
    size: "70,000 samples"
  }
];

const DatasetList: React.FC = () => {
  return (
    <div className="grid gap-4 p-4">
      {datasets.map((dataset) => (
        <div key={dataset.id} className="border rounded-lg p-4 hover:shadow-lg transition-shadow">
          <h3 className="text-xl font-bold">{dataset.name}</h3>
          <p className="text-gray-600">{dataset.description}</p>
          <p className="text-sm text-gray-500">Size: {dataset.size}</p>
        </div>
      ))}
    </div>
  );
};

export default DatasetList;