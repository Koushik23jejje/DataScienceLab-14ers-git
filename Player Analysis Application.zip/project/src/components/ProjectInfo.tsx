import React from 'react';

const ProjectInfo: React.FC = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Data Science Learning Hub</h2>
      <div className="space-y-4">
        <section>
          <h3 className="text-xl font-semibold">Project Overview</h3>
          <p className="text-gray-600">
            This project serves as a comprehensive learning platform for B.Tech Data Science students,
            featuring data visualization, analysis tools, and practical examples.
          </p>
        </section>
        
        <section>
          <h3 className="text-xl font-semibold">Key Features</h3>
          <ul className="list-disc list-inside text-gray-600">
            <li>Interactive data visualizations</li>
            <li>Sample datasets for practice</li>
            <li>Statistical analysis tools</li>
            <li>Machine learning examples</li>
          </ul>
        </section>

        <section>
          <h3 className="text-xl font-semibold">Technologies Used</h3>
          <ul className="list-disc list-inside text-gray-600">
            <li>React for UI components</li>
            <li>D3.js and Recharts for visualizations</li>
            <li>Material-UI for styling</li>
            <li>TypeScript for type safety</li>
          </ul>
        </section>
      </div>
    </div>
  );
};

export default ProjectInfo;