import React from 'react';
import ProjectInfo from './components/ProjectInfo';
import DatasetList from './components/DatasetList';
import VisualizationDemo from './components/VisualizationDemo';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-600 text-white p-4">
        <h1 className="text-3xl font-bold">Data Science Project Hub</h1>
      </header>
      
      <main className="container mx-auto py-8 px-4">
        <div className="grid gap-8">
          <ProjectInfo />
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold mb-4">Available Datasets</h2>
            <DatasetList />
          </div>
          <div className="bg-white rounded-lg shadow-md">
            <VisualizationDemo />
          </div>
        </div>
      </main>

      <footer className="bg-gray-800 text-white p-4 mt-8">
        <p className="text-center">© 2023 Data Science Project Hub</p>
      </footer>
    </div>
  );
}

export default App;